import CustomerService from "@/services/CustomerSevice";
import { StatusMessage, Role } from "@/types";

// const GUEST_ROLE: Role = "CUSTOMER"; // Define the GUEST role value
import classNames from "classnames";
import { useRouter } from "next/router";
import { useState } from "react";

const UserSignUpForm: React.FC = () => {

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [userName, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [role, setRole] = useState<Role | undefined>("CUSTOMER");
  const [ nameError, setNameError] = useState("");
  const [statusMessage, setStatusMessage] = useState<StatusMessage | undefined>(undefined)

  const [statusMessages, setStatusMessages]= useState<StatusMessage[]>([])
  const router = useRouter();

  const clearErrors = () => {
    //reset errors and status messages
    setNameError("");
    setStatusMessages([]);
  };

  const validate = (): boolean => {

    let result  = false

    if (!firstName || !lastName || !userName || !phone || !role) {
        setNameError('All fields are required');
        return false;
      }
    return result
     
  };
  const handleSubmit = async (event: any) => {

    event.preventDefault();
    clearErrors();

    
    //handle default browser behavior of refreshing the page after a form submitted
    
    if (!validate()) {
        return;
    }

    try {
        const response = await CustomerService.register({
          password,
          firstName,
          lastName,
          role,
          phone,
          username : userName,
        });
        const data = await response.json();
  
        if (response.status === 200) {
          sessionStorage.setItem('username', userName);
          setStatusMessage({ type: 'success', message: data.message });
          setTimeout(() => {
            router.push('/products');
          }, 2000);
        } else if (response.status === 401) {
          setStatusMessage({ type: 'error', message: data.errorMessage });
        }
      } catch (error) {
        console.error(error)
        setStatusMessage({ type: 'error', message: 'An error occurred during registration' });
      }
};


  return (
    <>
      <h3 className="px-0">Signup page</h3>
      {statusMessages && (
        <div className="row">
          <ul className="list-none mb-3 mx-auto ">
            {statusMessages.map(({ message, type }, index) => (
              <li
                key={index}
                className={classNames({
                  "text-red-800": type === "error",
                  "text-green-800": type === "success",
                })}
              >
                {message}
              </li>
            ))}
          </ul>
        </div>
      )}
      <form onSubmit={(event) => handleSubmit}>
        <input
          type="text"
          value={firstName}
          onChange={(event) => setFirstName(event.target.value)}
          placeholder="First Name"
          className="border border-gray-300 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
        />
        <input
          type="text"
          value={lastName}
          onChange={(event) => setLastName(event.target.value)}
          placeholder="Last Name"
          className="border border-gray-300 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
        />
        <input
          type="text"
          value={userName}
          onChange={(event) => setUserName(event.target.value)}
          placeholder="Username"
          className="border border-gray-300 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
        />
        <input
          type="password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          placeholder="Password"
          className="border border-gray-300 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
        />
        <input
          type="text"
          value={phone}
          onChange={(event) => setPhone(event.target.value)}
          placeholder="Phone"
          className="border border-gray-300 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
        />
        <input
          type="text"
          value={role}
          onChange={(event) => setRole(event.target.value as Role)}
          placeholder="Role"
          className="border border-gray-300 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
        />
        <button
          className="text-white bg-blue-700 hover:bg-blue-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center"
          type="submit"
        >
          Sign Up
        </button>
      </form>
    </>
  );
};

export default UserSignUpForm;
